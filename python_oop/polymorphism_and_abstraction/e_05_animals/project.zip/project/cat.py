from project.animal import Animal


class Cat(Animal):
    pass

    @staticmethod
    def make_sound():
        return "Meow meow!"