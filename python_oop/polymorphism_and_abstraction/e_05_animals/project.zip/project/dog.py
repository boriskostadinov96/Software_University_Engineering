from project.animal import Animal


class Dog(Animal):
    pass

    @staticmethod
    def make_sound():
        return "Woof!"