from unittest import TestCase, main
from collections import deque

from project.railway_station import RailwayStation


class TestRailwayStation(TestCase):
    def setUp(self):
        self.station = RailwayStation("Sofia")

    def test_correct_init(self):
        self.assertEqual("Sofia", self.station.name)
        self.assertEqual(deque(), self.station.arrival_trains)
        self.assertEqual(deque(), self.station.departure_trains)

    def test_name_len_lower_than_or_equal_three_symbols_raises_value_error(self):
        with self.assertRaises(ValueError) as ve:
            self.station.name = ""

        self.assertEqual("Name should be more than 3 symbols!", str(ve.exception))

        with self.assertRaises(ValueError) as ve:
            self.station.name = "asd"

        self.assertEqual("Name should be more than 3 symbols!", str(ve.exception))


if __name__ == "__main__":
    main()
