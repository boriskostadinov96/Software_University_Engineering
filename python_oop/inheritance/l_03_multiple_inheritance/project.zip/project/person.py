class Person:

    def sleep(self) -> str:
        return "sleeping..."
