from project.animal import Animal
from project.dog import Dog

animal = Animal()
print(animal.eat())

dog = Dog()
print(dog.bark())