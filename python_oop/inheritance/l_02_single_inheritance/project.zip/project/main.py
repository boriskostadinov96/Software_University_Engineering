from project.animal import Animal
from project.dog import Dog

dog = Dog()
print(dog.eat())